-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 29 mai 2024 à 16:51
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : mediatek86_bdd
--
CREATE DATABASE IF NOT EXISTS mediatek86_bdd DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'mediatek86'@'%' IDENTIFIED BY 'motdepasseuser';
GRANT USAGE ON *.* TO 'mediatek86'@'%';
GRANT ALL PRIVILEGES ON `mediatek86_bdd`.* TO 'mediatek86'@'%';
USE mediatek86_bdd;

-- --------------------------------------------------------

--
-- Structure de la table absence
--

DROP TABLE IF EXISTS absence;
CREATE TABLE absence (
  idpersonnel int NOT NULL,
  datedebut datetime NOT NULL,
  datefin datetime DEFAULT NULL,
  idmotif int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table absence
--

INSERT INTO absence (idpersonnel, datedebut, datefin, idmotif) VALUES
(14, '2024-02-19 08:30:21', '2024-02-21 09:00:00', 2),
(14, '2024-03-05 08:30:21', '2024-03-14 15:00:00', 3),
(13, '2024-05-01 08:00:21', '2024-05-04 07:00:00', 3),
(14, '2024-04-09 08:30:21', '2024-04-10 16:00:00', 1),
(12, '2023-07-03 07:30:21', '2023-07-17 13:00:00', 1),
(12, '2024-02-14 07:30:21', '2024-02-17 13:00:00', 3),
(9, '2024-02-01 07:30:21', '2024-02-09 13:00:00', 2),
(10, '2023-12-06 07:30:21', '2023-12-08 13:00:00', 2),
(7, '2023-10-04 07:30:21', '2023-10-12 13:00:00', 1),
(7, '2023-08-16 07:30:21', '2023-08-31 13:00:00', 1),
(1, '2024-03-13 07:30:21', '2024-03-28 13:00:00', 1),
(1, '2024-04-10 07:30:21', '2024-04-19 13:00:00', 1),
(1, '2024-05-16 07:30:21', '2024-05-18 13:00:00', 2),
(7, '2024-04-11 08:00:21', '2024-04-14 08:00:00', 4),
(15, '2024-03-20 08:00:21', '2024-03-22 08:00:00', 4),
(15, '2024-03-07 08:00:21', '2024-03-13 08:00:00', 2),
(10, '2024-01-05 08:00:21', '2024-01-19 08:00:00', 1),
(10, '2023-12-12 08:00:21', '2023-12-27 08:00:00', 3),
(9, '2023-12-07 08:00:21', '2023-12-11 08:00:00', 4),
(9, '2023-10-27 08:00:21', '2023-10-29 08:00:00', 2),
(2, '2023-10-11 08:00:21', '2023-10-27 08:00:00', 1),
(2, '2024-03-13 08:00:21', '2024-03-16 08:00:00', 3),
(2, '2024-05-03 08:00:21', '2024-05-04 08:00:00', 1),
(16, '2024-05-14 08:00:21', '2024-05-16 08:00:00', 3),
(16, '2023-10-09 08:00:21', '2023-10-13 08:00:00', 2),
(16, '2023-11-10 08:00:21', '2023-11-22 08:00:00', 2),
(12, '2023-11-22 08:00:21', '2023-11-24 08:00:00', 2),
(12, '2023-10-24 08:00:21', '2023-10-27 08:00:00', 2),
(12, '2024-04-03 08:00:21', '2024-04-04 08:00:00', 4),
(8, '2024-02-06 08:00:21', '2024-02-08 10:00:00', 3),
(8, '2024-03-05 08:00:21', '2024-03-23 10:00:00', 1),
(8, '2024-05-07 08:00:21', '2024-05-09 09:00:00', 2),
(5, '2024-04-10 08:00:21', '2024-04-18 09:00:00', 1),
(5, '2024-03-06 08:00:21', '2024-03-09 13:00:00', 3),
(3, '2024-03-13 08:00:21', '2024-03-14 15:00:00', 4),
(3, '2024-01-10 08:00:21', '2024-01-25 08:00:00', 1),
(6, '2023-11-24 08:00:21', '2023-11-29 08:00:00', 4),
(6, '2023-11-16 16:00:21', '2023-11-17 08:00:00', 2),
(11, '2023-11-28 16:00:21', '2023-11-30 08:00:00', 1),
(11, '2024-01-17 09:00:21', '2024-01-19 16:00:00', 1),
(11, '2023-12-12 09:00:21', '2023-12-21 16:00:00', 2),
(4, '2024-03-20 09:00:21', '2024-03-23 16:00:00', 2),
(4, '2024-03-05 07:00:21', '2024-03-07 15:00:00', 1),
(13, '2024-04-09 08:00:21', '2024-04-11 15:00:00', 2),
(13, '2024-02-14 17:00:21', '2024-02-17 09:00:00', 4);

-- --------------------------------------------------------

--
-- Structure de la table motif
--

DROP TABLE IF EXISTS motif;
CREATE TABLE motif (
  idmotif int NOT NULL,
  libelle varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table motif
--

INSERT INTO motif (idmotif, libelle) VALUES
(1, 'vacances'),
(2, 'maladie'),
(3, 'motif familial'),
(4, 'congé parental');

-- --------------------------------------------------------

--
-- Structure de la table personnel
--

DROP TABLE IF EXISTS personnel;
CREATE TABLE personnel (
  idpersonnel int NOT NULL,
  nom varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  prenom varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  tel varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  mail varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  idservice int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table personnel
--

INSERT INTO personnel (idpersonnel, nom, prenom, tel, mail, idservice) VALUES
(1, 'Yang', 'Naida', '06 73 16 68 58', 'sem@yahoo.fr', 2),
(2, 'Norton', 'Wanda', '07 31 13 88 32', 'quis@yahoo.fr', 2),
(3, 'Duke', 'Kirestin', '06 10 56 47 97', 'mattis.cras@hotmail.com', 3),
(4, 'Burke', 'Guy', '06 77 58 35 30', 'phasellus.nulla@yahoo.com', 1),
(5, 'Garza', 'Sophia', '07 48 07 43 82', 'lorem.vehicula@google.com', 2),
(6, 'Clarke', 'Caryn', '07 55 12 48 56', 'egestas@yahoo.com', 3),
(7, 'Williams', 'Fleur', '06 15 96 11 65', 'ornare@yahoo.com', 2),
(8, 'Hayden', 'Regan', '07 22 41 17 84', 'lacinia@yahoo.com', 2),
(9, 'O\'brien', 'Kimberly', '06 28 37 86 54', 'eleifend.vitae@yahoo.fr', 2),
(10, 'Parker', 'Nigel', '06 14 50 34 94', 'commodo.ipsum@google.com', 2),
(11, 'Christian', 'Deanna', '06 38 77 25 50', 'aliquam.adipiscing@google.fr', 1),
(12, 'Mckee', 'Elmo', '07 07 97 87 65', 'neque.venenatis@outlook.fr', 2),
(14, 'Cannan', 'Fabrice', '06 65 78 39 73', 'fab@gmail.com', 1),
(13, 'Berry', 'Carissa', '07 70 03 36 88', 'mi.ac@outlook.com', 2),
(15, 'Tyson', 'Venus', '06 88 22 46 46', 'sed@outlook.com', 1),
(63, 'Jackson', 'Michael', '06 73 82 94 28', 'mj@gmail.com', 2),
(16, 'Morin', 'Ignatius', '07 64 18 51 52', 'a.feugiat.tellus@yahoo.com', 1);

-- --------------------------------------------------------

--
-- Structure de la table responsable
--

DROP TABLE IF EXISTS responsable;
CREATE TABLE responsable (
  login varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  pwd varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table responsable
--

INSERT INTO responsable (login, pwd) VALUES
('davis', '5b0a783ee76aa1c8db7257938399c87e9721eb24fc6011e12f9a6b88a09d1ac4');

-- --------------------------------------------------------

--
-- Structure de la table service
--

DROP TABLE IF EXISTS service;
CREATE TABLE service (
  idservice int NOT NULL,
  nom varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table service
--

INSERT INTO service (idservice, nom) VALUES
(1, 'administratif'),
(2, 'médiation culturelle'),
(3, 'prêt');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table absence
--
ALTER TABLE absence
  ADD PRIMARY KEY (idpersonnel,datedebut),
  ADD KEY idmotif (idmotif);

--
-- Index pour la table motif
--
ALTER TABLE motif
  ADD PRIMARY KEY (idmotif);

--
-- Index pour la table personnel
--
ALTER TABLE personnel
  ADD PRIMARY KEY (idpersonnel),
  ADD KEY idservice (idservice);

--
-- Index pour la table service
--
ALTER TABLE service
  ADD PRIMARY KEY (idservice);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table motif
--
ALTER TABLE motif
  MODIFY idmotif int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table personnel
--
ALTER TABLE personnel
  MODIFY idpersonnel int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT pour la table service
--
ALTER TABLE service
  MODIFY idservice int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
